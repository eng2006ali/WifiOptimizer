# ALPHA WiFi Optimizer — Android

تطبيق Android أصلي بلغة Kotlin لتحسين شبكة الواي فاي.

## المميزات

- **اختبار سرعة حقيقي** — Download / Upload / Ping / Jitter
- **مسح الشبكات** — كشف القنوات المزدحمة وأفضل قناة
- **مراقبة البينغ** — رسم بياني حي كل ثانية
- **اختبار سيرفرات الألعاب** — PUBG / Free Fire / COD / Valorant
- **الدخول للراوتر** — بالـ IP + username + password
- **تحسين تلقائي** — DNS + Network Score + Gaming Mode

## طريقة البناء

### المتطلبات
- Android Studio Hedgehog أو أحدث
- JDK 17
- Android SDK 34

### الخطوات

```
1. افتح Android Studio
2. File → Open → اختر مجلد WifiOptimizer
3. انتظر Gradle Sync ينتهي
4. Run → Run 'app'
```

### أو Build APK مباشرة

```bash
cd WifiOptimizer
./gradlew assembleDebug

# APK يكون في:
# app/build/outputs/apk/debug/app-debug.apk
```

## الصلاحيات المطلوبة

- `ACCESS_WIFI_STATE` — قراءة معلومات الواي فاي
- `CHANGE_WIFI_STATE` — تغيير إعدادات الواي فاي
- `ACCESS_FINE_LOCATION` — مطلوب لمسح الشبكات
- `INTERNET` — اختبار السرعة والبينغ

## هيكل المشروع

```
app/src/main/java/com/alpha/wifioptimizer/
├── ui/
│   ├── MainActivity.kt     — الشاشة الرئيسية
│   └── PingGraphView.kt    — رسم بياني مخصص للبينغ
├── network/
│   ├── WifiAnalyzer.kt     — معلومات الواي فاي الحقيقية
│   ├── SpeedTester.kt      — اختبار السرعة الحقيقي
│   └── RouterManager.kt    — الدخول للراوتر
└── utils/
    └── PingMonitor.kt      — مراقبة البينغ الفوري
```
