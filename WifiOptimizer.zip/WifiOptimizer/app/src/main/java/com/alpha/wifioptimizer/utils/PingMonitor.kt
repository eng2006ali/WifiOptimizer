package com.alpha.wifioptimizer.utils

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.HttpURLConnection
import java.net.URL

data class PingResult(
    val current: Long,
    val min: Long,
    val max: Long,
    val avg: Long,
    val packetLoss: Int
)

class PingMonitor {

    private val history   = mutableListOf<Long>()
    private var running   = false
    private var lossCount = 0
    private var totalCount= 0

    suspend fun startMonitoring(onResult: (PingResult) -> Unit) {
        running = true
        while (running) {
            val ping = pingGoogle()
            totalCount++
            if (ping < 0) lossCount++ else history.add(ping)
            if (history.size > 60) history.removeAt(0)

            if (history.isNotEmpty()) {
                onResult(PingResult(
                    current    = history.last(),
                    min        = history.min(),
                    max        = history.max(),
                    avg        = history.average().toLong(),
                    packetLoss = (lossCount * 100) / totalCount
                ))
            }
            delay(1000)
        }
    }

    // Real HTTP-based ping (works without root)
    private suspend fun pingGoogle(): Long = withContext(Dispatchers.IO) {
        try {
            val start = System.currentTimeMillis()
            val url   = URL("https://www.google.com/favicon.ico?_=${System.nanoTime()}")
            val conn  = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.readTimeout    = 3000
            conn.instanceFollowRedirects = false
            conn.connect()
            val rtt = System.currentTimeMillis() - start
            conn.disconnect()
            rtt
        } catch (e: Exception) { -1L }
    }

    // Ping specific host
    suspend fun pingHost(host: String): Long = withContext(Dispatchers.IO) {
        try {
            val start   = System.currentTimeMillis()
            val address = InetAddress.getByName(host)
            val reachable = address.isReachable(3000)
            val rtt     = System.currentTimeMillis() - start
            if (reachable) rtt else rtt + 50 // Fallback
        } catch (e: Exception) {
            try {
                // Fallback to HTTP
                val start = System.currentTimeMillis()
                val url   = URL("https://$host")
                val conn  = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 3000
                conn.connect()
                val rtt = System.currentTimeMillis() - start
                conn.disconnect()
                rtt
            } catch (e2: Exception) { 999L }
        }
    }

    fun stop() { running = false }
}
