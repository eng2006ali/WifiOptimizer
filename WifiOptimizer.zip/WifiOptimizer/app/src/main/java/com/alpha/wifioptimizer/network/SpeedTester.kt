package com.alpha.wifioptimizer.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL

data class SpeedResult(
    val downloadMbps: String,
    val uploadMbps: String,
    val pingMs: Long,
    val jitterMs: Long
)

class SpeedTester {

    // Multiple test servers for accuracy
    private val downloadUrls = listOf(
        "https://speed.cloudflare.com/__down?bytes=10000000",
        "https://httpbin.org/bytes/5000000",
        "https://link.testfile.org/5MB"
    )

    private val pingHosts = listOf("8.8.8.8", "1.1.1.1", "208.67.222.222")

    suspend fun runTest(onProgress: (Int) -> Unit): SpeedResult = withContext(Dispatchers.IO) {

        // ── PING ──────────────────────────────────────
        onProgress(5)
        val pings = mutableListOf<Long>()
        repeat(5) {
            val start = System.currentTimeMillis()
            try {
                val url = URL("https://www.google.com/favicon.ico?t=${System.nanoTime()}")
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 3000
                conn.readTimeout = 3000
                conn.connect()
                conn.disconnect()
            } catch (e: Exception) { /* ignore */ }
            pings.add(System.currentTimeMillis() - start)
        }
        val avgPing   = pings.average().toLong()
        val jitter    = (pings.max() - pings.min())
        onProgress(20)

        // ── DOWNLOAD ──────────────────────────────────
        var downloadMbps = "0.0"
        for (urlStr in downloadUrls) {
            try {
                val url  = URL(urlStr)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 5000
                conn.readTimeout    = 15000
                conn.connect()

                val startTime  = System.currentTimeMillis()
                var totalBytes = 0L
                val buffer     = ByteArray(8192)
                val stream     = conn.inputStream

                var p = 20
                while (true) {
                    val read = stream.read(buffer)
                    if (read == -1) break
                    totalBytes += read
                    p = minOf(p + 1, 60)
                    onProgress(p)
                }
                stream.close()
                conn.disconnect()

                val elapsed  = (System.currentTimeMillis() - startTime) / 1000.0
                val mbps     = (totalBytes * 8.0) / (elapsed * 1_000_000)
                downloadMbps = String.format("%.1f", mbps)
                break
            } catch (e: Exception) { continue }
        }
        onProgress(65)

        // ── UPLOAD ────────────────────────────────────
        var uploadMbps = "0.0"
        try {
            val url  = URL("https://httpbin.org/post")
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod   = "POST"
            conn.doOutput        = true
            conn.connectTimeout  = 5000
            conn.readTimeout     = 15000
            conn.setRequestProperty("Content-Type", "application/octet-stream")

            val uploadData = ByteArray(2_000_000) { it.toByte() } // 2MB
            val startTime  = System.currentTimeMillis()

            val out = conn.outputStream
            out.write(uploadData)
            out.flush()
            out.close()

            conn.inputStream.close()
            conn.disconnect()

            val elapsed = (System.currentTimeMillis() - startTime) / 1000.0
            val mbps    = (uploadData.size * 8.0) / (elapsed * 1_000_000)
            uploadMbps  = String.format("%.1f", mbps)
        } catch (e: Exception) {
            uploadMbps = "—"
        }
        onProgress(100)

        SpeedResult(
            downloadMbps = downloadMbps,
            uploadMbps   = uploadMbps,
            pingMs       = avgPing,
            jitterMs     = jitter
        )
    }
}
