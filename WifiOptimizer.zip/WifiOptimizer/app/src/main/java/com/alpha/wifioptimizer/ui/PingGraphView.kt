package com.alpha.wifioptimizer.ui

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View

class PingGraphView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private val pings = mutableListOf<Long>()

    private val paintLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF88")
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }
    private val paintFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1A00FF88")
        style = Paint.Style.FILL
    }
    private val paintDot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00FF88")
        style = Paint.Style.FILL
    }
    private val paintText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#5A6478")
        textSize = 24f
    }

    fun addPing(ping: Long) {
        pings.add(ping)
        if (pings.size > 60) pings.removeAt(0)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (pings.size < 2) return

        val w = width.toFloat()
        val h = height.toFloat()
        val pad = 8f

        val maxPing = maxOf(pings.max().toFloat(), 100f)
        val minPing = 0f

        fun pingToY(p: Long): Float =
            h - pad - ((p - minPing) / (maxPing - minPing)) * (h - pad * 2)

        fun indexToX(i: Int): Float =
            pad + (i.toFloat() / (pings.size - 1)) * (w - pad * 2)

        // Build path
        val path = Path()
        val fill = Path()

        path.moveTo(indexToX(0), pingToY(pings[0]))
        fill.moveTo(indexToX(0), h)
        fill.lineTo(indexToX(0), pingToY(pings[0]))

        for (i in 1 until pings.size) {
            val x = indexToX(i)
            val y = pingToY(pings[i])
            path.lineTo(x, y)
            fill.lineTo(x, y)
        }

        fill.lineTo(indexToX(pings.size - 1), h)
        fill.close()

        // Draw fill + line
        canvas.drawPath(fill, paintFill)
        canvas.drawPath(path, paintLine)

        // Draw last dot
        val lastX = indexToX(pings.size - 1)
        val lastY = pingToY(pings.last())
        canvas.drawCircle(lastX, lastY, 5f, paintDot)

        // Draw last ping value
        canvas.drawText("${pings.last()}ms", lastX - 30f, lastY - 12f, paintText)
    }
}
