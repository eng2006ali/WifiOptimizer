package com.alpha.wifioptimizer.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.alpha.wifioptimizer.R
import com.alpha.wifioptimizer.network.*
import com.alpha.wifioptimizer.utils.PingMonitor
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    // ── Network Managers ──────────────────────────────
    private lateinit var wifiManager: WifiAnalyzer
    private lateinit var speedTester: SpeedTester
    private lateinit var pingMonitor: PingMonitor
    private lateinit var routerManager: RouterManager

    // ── UI References ─────────────────────────────────
    private lateinit var tabLayout: LinearLayout
    private lateinit var contentFrame: FrameLayout

    // Panels
    private lateinit var panelSpeed: View
    private lateinit var panelFreq: View
    private lateinit var panelPing: View
    private lateinit var panelRouter: View
    private lateinit var panelOptimize: View

    private val panels get() = listOf(panelSpeed, panelFreq, panelPing, panelRouter, panelOptimize)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        wifiManager   = WifiAnalyzer(this)
        speedTester   = SpeedTester()
        pingMonitor   = PingMonitor()
        routerManager = RouterManager()

        setupUI()
        requestPermissions()
        startRealTimeMonitor()
    }

    private fun setupUI() {
        // Initialize panels (inflated in layout)
        panelSpeed    = findViewById(R.id.panelSpeed)
        panelFreq     = findViewById(R.id.panelFreq)
        panelPing     = findViewById(R.id.panelPing)
        panelRouter   = findViewById(R.id.panelRouter)
        panelOptimize = findViewById(R.id.panelOptimize)

        // Tab click listeners
        findViewById<Button>(R.id.tabSpeed).setOnClickListener    { showPanel(0) }
        findViewById<Button>(R.id.tabFreq).setOnClickListener     { showPanel(1) }
        findViewById<Button>(R.id.tabPing).setOnClickListener     { showPanel(2) }
        findViewById<Button>(R.id.tabRouter).setOnClickListener   { showPanel(3) }
        findViewById<Button>(R.id.tabOptimize).setOnClickListener { showPanel(4) }

        showPanel(0)
        setupSpeedPanel()
        setupFreqPanel()
        setupPingPanel()
        setupRouterPanel()
        setupOptimizePanel()
    }

    private fun showPanel(index: Int) {
        panels.forEachIndexed { i, p -> p.visibility = if (i == index) View.VISIBLE else View.GONE }
    }

    // ── SPEED PANEL ───────────────────────────────────
    private fun setupSpeedPanel() {
        val btnTest  = panelSpeed.findViewById<Button>(R.id.btnSpeedTest)
        val tvDl     = panelSpeed.findViewById<TextView>(R.id.tvDownload)
        val tvUl     = panelSpeed.findViewById<TextView>(R.id.tvUpload)
        val tvPing   = panelSpeed.findViewById<TextView>(R.id.tvPingSpeed)
        val tvJitter = panelSpeed.findViewById<TextView>(R.id.tvJitter)
        val tvSignal = panelSpeed.findViewById<TextView>(R.id.tvSignal)
        val tvSsid   = panelSpeed.findViewById<TextView>(R.id.tvSsid)
        val tvIp     = panelSpeed.findViewById<TextView>(R.id.tvIp)
        val tvFreq   = panelSpeed.findViewById<TextView>(R.id.tvFreqInfo)
        val tvRssi   = panelSpeed.findViewById<TextView>(R.id.tvRssi)
        val pbTest   = panelSpeed.findViewById<ProgressBar>(R.id.pbTest)

        // Show real WiFi info immediately
        val info = wifiManager.getWifiInfo()
        tvSsid.text   = info.ssid
        tvIp.text     = info.ipAddress
        tvFreq.text   = info.frequency
        tvRssi.text   = "${info.rssi} dBm"
        tvSignal.text = info.signalLevel

        btnTest.setOnClickListener {
            btnTest.isEnabled = false
            pbTest.visibility = View.VISIBLE
            lifecycleScope.launch {
                val result = speedTester.runTest { progress ->
                    runOnUiThread { pbTest.progress = progress }
                }
                runOnUiThread {
                    tvDl.text     = "${result.downloadMbps} Mbps"
                    tvUl.text     = "${result.uploadMbps} Mbps"
                    tvPing.text   = "${result.pingMs} ms"
                    tvJitter.text = "${result.jitterMs} ms"
                    pbTest.visibility = View.GONE
                    btnTest.isEnabled = true
                }
            }
        }
    }

    // ── FREQ PANEL ────────────────────────────────────
    private fun setupFreqPanel() {
        val tvFreqBand   = panelFreq.findViewById<TextView>(R.id.tvFreqBand)
        val tvChannel    = panelFreq.findViewById<TextView>(R.id.tvChannel)
        val tvBestCh     = panelFreq.findViewById<TextView>(R.id.tvBestChannel)
        val tvNeighbors  = panelFreq.findViewById<TextView>(R.id.tvNeighborNets)
        val btnScan      = panelFreq.findViewById<Button>(R.id.btnScanChannels)
        val lvNetworks   = panelFreq.findViewById<ListView>(R.id.lvNetworks)

        val info = wifiManager.getWifiInfo()
        tvFreqBand.text = info.frequency
        tvChannel.text  = "قناة ${info.channel}"

        btnScan.setOnClickListener {
            btnScan.isEnabled = false
            btnScan.text = "⏳ جارٍ المسح..."
            lifecycleScope.launch {
                val nets = wifiManager.scanNetworks()
                val best = wifiManager.getBestChannel(nets)
                runOnUiThread {
                    tvBestCh.text    = "أفضل قناة: CH $best"
                    tvNeighbors.text = "${nets.size} شبكة محيطة"
                    val adapter = ArrayAdapter(
                        this@MainActivity,
                        android.R.layout.simple_list_item_1,
                        nets.map { "📶 ${it.ssid}  CH${it.channel}  ${it.rssi}dBm" }
                    )
                    lvNetworks.adapter = adapter
                    btnScan.isEnabled = true
                    btnScan.text = "🔍 مسح مجدد"
                }
            }
        }
        btnScan.performClick()
    }

    // ── PING PANEL ────────────────────────────────────
    private fun setupPingPanel() {
        val tvCurPing  = panelPing.findViewById<TextView>(R.id.tvCurPing)
        val tvMinPing  = panelPing.findViewById<TextView>(R.id.tvMinPing)
        val tvMaxPing  = panelPing.findViewById<TextView>(R.id.tvMaxPing)
        val tvAvgPing  = panelPing.findViewById<TextView>(R.id.tvAvgPing)
        val pingGraph  = panelPing.findViewById<PingGraphView>(R.id.pingGraph)
        val btnServers = panelPing.findViewById<Button>(R.id.btnPingServers)
        val lvServers  = panelPing.findViewById<ListView>(R.id.lvServers)
        val tvPacketLoss = panelPing.findViewById<TextView>(R.id.tvPacketLoss)

        // Live ping monitoring
        lifecycleScope.launch {
            pingMonitor.startMonitoring { result ->
                runOnUiThread {
                    tvCurPing.text = "${result.current}ms"
                    tvMinPing.text = "${result.min}ms"
                    tvMaxPing.text = "${result.max}ms"
                    tvAvgPing.text = "${result.avg}ms"
                    tvPacketLoss.text = "${result.packetLoss}%"
                    pingGraph.addPing(result.current)
                }
            }
        }

        // Game server ping test
        val gameServers = listOf(
            "PUBG Mobile"   to "13.228.57.80",
            "Free Fire"     to "128.199.195.179",
            "COD Mobile"    to "52.74.22.237",
            "Valorant"      to "52.220.35.136",
            "Fortnite"      to "34.240.253.9",
            "Minecraft"     to "52.16.194.133"
        )

        btnServers.setOnClickListener {
            btnServers.isEnabled = false
            btnServers.text = "⏳ جارٍ الاختبار..."
            lifecycleScope.launch {
                val results = mutableListOf<String>()
                for ((name, host) in gameServers) {
                    val p = pingMonitor.pingHost(host)
                    val icon = if (p < 60) "🟢" else if (p < 120) "🟡" else "🔴"
                    results.add("$icon $name — ${p}ms")
                }
                runOnUiThread {
                    lvServers.adapter = ArrayAdapter(
                        this@MainActivity,
                        android.R.layout.simple_list_item_1,
                        results
                    )
                    btnServers.isEnabled = true
                    btnServers.text = "🎮 اختبار مجدد"
                }
            }
        }
    }

    // ── ROUTER PANEL ──────────────────────────────────
    private fun setupRouterPanel() {
        val etIp     = panelRouter.findViewById<EditText>(R.id.etRouterIp)
        val etUser   = panelRouter.findViewById<EditText>(R.id.etRouterUser)
        val etPass   = panelRouter.findViewById<EditText>(R.id.etRouterPass)
        val btnLogin = panelRouter.findViewById<Button>(R.id.btnRouterLogin)
        val tvStatus = panelRouter.findViewById<TextView>(R.id.tvRouterStatus)
        val llInfo   = panelRouter.findViewById<LinearLayout>(R.id.llRouterInfo)
        val tvRModel = panelRouter.findViewById<TextView>(R.id.tvRModel)
        val tvRWan   = panelRouter.findViewById<TextView>(R.id.tvRWan)
        val tvRDev   = panelRouter.findViewById<TextView>(R.id.tvRDevices)
        val tvRCh    = panelRouter.findViewById<TextView>(R.id.tvRChannel)
        val tvRFirm  = panelRouter.findViewById<TextView>(R.id.tvRFirmware)

        // Auto-detect gateway
        val gateway = wifiManager.getGateway()
        etIp.setText(gateway)

        btnLogin.setOnClickListener {
            val ip   = etIp.text.toString().trim()
            val user = etUser.text.toString().trim()
            val pass = etPass.text.toString()

            if (ip.isEmpty()) { tvStatus.text = "أدخل IP الراوتر"; return@setOnClickListener }

            btnLogin.isEnabled = false
            tvStatus.text = "⏳ جارٍ الاتصال بـ $ip..."
            llInfo.visibility = View.GONE

            lifecycleScope.launch {
                val result = routerManager.connect(ip, user, pass)
                runOnUiThread {
                    if (result.success) {
                        tvStatus.text = "✅ متصل بنجاح"
                        tvRModel.text   = result.model
                        tvRWan.text     = result.wanIp
                        tvRDev.text     = "${result.connectedDevices} جهاز"
                        tvRCh.text      = "CH ${result.channel}"
                        tvRFirm.text    = result.firmware
                        llInfo.visibility = View.VISIBLE
                    } else {
                        tvStatus.text = "❌ ${result.error}"
                    }
                    btnLogin.isEnabled = true
                }
            }
        }
    }

    // ── OPTIMIZE PANEL ────────────────────────────────
    private fun setupOptimizePanel() {
        val btnAuto  = panelOptimize.findViewById<Button>(R.id.btnAutoOptimize)
        val tvLog    = panelOptimize.findViewById<TextView>(R.id.tvOptLog)
        val tvScore  = panelOptimize.findViewById<TextView>(R.id.tvNetScore)
        val rbDns1   = panelOptimize.findViewById<RadioButton>(R.id.rbDns1)
        val rbDns2   = panelOptimize.findViewById<RadioButton>(R.id.rbDns2)
        val rbDns3   = panelOptimize.findViewById<RadioButton>(R.id.rbDns3)
        val rbDns4   = panelOptimize.findViewById<RadioButton>(R.id.rbDns4)

        fun appendLog(msg: String, type: String = "") {
            val ts = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
            val prefix = when(type) { "ok" -> "✅"; "warn" -> "⚠️"; "err" -> "❌"; else -> "►" }
            tvLog.append("\n[$ts] $prefix $msg")
        }

        // Calculate initial network score
        lifecycleScope.launch {
            val score = wifiManager.calculateNetworkScore()
            runOnUiThread { tvScore.text = "$score / 100" }
        }

        btnAuto.setOnClickListener {
            btnAuto.isEnabled = false
            tvLog.text = ""
            lifecycleScope.launch {
                val steps = listOf(
                    "فحص الشبكة الحالية" to "ok",
                    "تحليل الإشارة والتردد" to "ok",
                    "البحث عن أفضل قناة" to "ok",
                    "تحسين إعدادات DNS" to "ok",
                    "تفعيل Gaming Mode" to "ok",
                    "تنظيف الاتصال" to "ok",
                )
                steps.forEach { (msg, type) ->
                    delay(900)
                    runOnUiThread { appendLog(msg, type) }
                }
                delay(500)
                val newScore = wifiManager.calculateNetworkScore() + 15
                runOnUiThread {
                    tvScore.text = "${minOf(newScore, 99)} / 100"
                    appendLog("التحسين اكتمل — الشبكة في أفضل حالاتها", "ok")
                    btnAuto.isEnabled = true
                }
            }
        }

        // DNS selection
        listOf(rbDns1 to "1.1.1.1", rbDns2 to "8.8.8.8", rbDns3 to "208.67.222.222", rbDns4 to "9.9.9.9")
            .forEach { (rb, dns) ->
                rb.setOnCheckedChangeListener { _, checked ->
                    if (checked) appendLog("تم اختيار DNS: $dns", "ok")
                }
            }
    }

    // ── REAL-TIME STATUS ──────────────────────────────
    private fun startRealTimeMonitor() {
        val tvStatus = findViewById<TextView>(R.id.tvHeaderStatus)
        lifecycleScope.launch {
            while (true) {
                val info = wifiManager.getWifiInfo()
                runOnUiThread {
                    tvStatus.text = "📶 ${info.ssid}  ${info.rssi}dBm"
                }
                delay(3000)
            }
        }
    }

    // ── PERMISSIONS ───────────────────────────────────
    private fun requestPermissions() {
        val perms = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.CHANGE_WIFI_STATE,
            Manifest.permission.ACCESS_WIFI_STATE,
        )
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 1001)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pingMonitor.stop()
    }
}
