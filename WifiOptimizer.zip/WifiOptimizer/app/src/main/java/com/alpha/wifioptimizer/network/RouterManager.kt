package com.alpha.wifioptimizer.network

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import android.util.Base64

data class RouterResult(
    val success: Boolean,
    val model: String = "—",
    val firmware: String = "—",
    val wanIp: String = "—",
    val channel: Int = 0,
    val connectedDevices: Int = 0,
    val error: String = ""
)

class RouterManager {

    suspend fun connect(ip: String, user: String, pass: String): RouterResult =
        withContext(Dispatchers.IO) {

        // Try HTTP Basic Auth first (most routers)
        val endpoints = listOf(
            "http://$ip/",
            "http://$ip/info.html",
            "http://$ip/status.html",
            "http://$ip/api/v1/status",
            "http://$ip/cgi-bin/luci",
        )

        val credentials = if (user.isNotEmpty() || pass.isNotEmpty()) {
            Base64.encodeToString("$user:$pass".toByteArray(), Base64.NO_WRAP)
        } else null

        for (endpoint in endpoints) {
            try {
                val url  = URL(endpoint)
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 4000
                conn.readTimeout    = 4000
                conn.instanceFollowRedirects = true

                // Add auth header if credentials provided
                credentials?.let {
                    conn.setRequestProperty("Authorization", "Basic $it")
                }
                conn.setRequestProperty("User-Agent", "Mozilla/5.0")

                val code = conn.responseCode

                // Read response to detect router type
                val body = try {
                    conn.inputStream.bufferedReader().use { it.readText() }
                } catch (e: Exception) {
                    conn.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                }
                conn.disconnect()

                if (code in 200..299 || code == 302) {
                    val model = detectRouterModel(body, ip)
                    return@withContext RouterResult(
                        success          = true,
                        model            = model,
                        firmware         = detectFirmware(body),
                        wanIp            = "جارٍ الجلب...",
                        channel          = detectChannel(body),
                        connectedDevices = estimateDevices(body),
                    )
                }

                // 401 = needs auth
                if (code == 401) {
                    return@withContext RouterResult(
                        success = false,
                        error   = "خطأ في كلمة المرور — كود 401"
                    )
                }

            } catch (e: Exception) { continue }
        }

        // Last resort: just check if router is reachable
        return@withContext try {
            val url  = URL("http://$ip/")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 3000
            conn.connect()
            conn.disconnect()
            RouterResult(
                success = true,
                model   = "راوتر غير معروف",
                error   = ""
            )
        } catch (e: Exception) {
            RouterResult(
                success = false,
                error   = "تعذر الوصول إلى $ip"
            )
        }
    }

    private fun detectRouterModel(body: String, ip: String): String {
        return when {
            body.contains("TP-Link", ignoreCase = true)  -> "TP-Link Router"
            body.contains("HUAWEI", ignoreCase = true)   -> "Huawei Router"
            body.contains("ZTE",    ignoreCase = true)   -> "ZTE Router"
            body.contains("D-Link", ignoreCase = true)   -> "D-Link Router"
            body.contains("Asus",   ignoreCase = true)   -> "ASUS Router"
            body.contains("Netgear",ignoreCase = true)   -> "Netgear Router"
            body.contains("Mikrotik",ignoreCase = true)  -> "MikroTik Router"
            body.contains("luci",   ignoreCase = true)   -> "OpenWRT Router"
            else -> "Router @ $ip"
        }
    }

    private fun detectFirmware(body: String): String {
        val pattern = Regex("firmware[:\\s]+([\\d.]+)", RegexOption.IGNORE_CASE)
        return pattern.find(body)?.groupValues?.get(1) ?: "غير متاح"
    }

    private fun detectChannel(body: String): Int {
        val pattern = Regex("channel[:\\s\"]+([\\d]+)", RegexOption.IGNORE_CASE)
        return pattern.find(body)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    private fun estimateDevices(body: String): Int {
        val pattern = Regex("(device|client|station)[s]?[:\\s\"]+([\\d]+)", RegexOption.IGNORE_CASE)
        return pattern.find(body)?.groupValues?.get(2)?.toIntOrNull() ?: 0
    }
}
