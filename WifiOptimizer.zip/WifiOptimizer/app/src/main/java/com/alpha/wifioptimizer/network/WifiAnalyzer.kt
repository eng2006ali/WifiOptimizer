package com.alpha.wifioptimizer.network

import android.content.Context
import android.net.wifi.WifiManager
import android.net.wifi.ScanResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetAddress

data class WifiInfo(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val frequency: String,
    val channel: Int,
    val ipAddress: String,
    val signalLevel: String,
    val linkSpeed: Int
)

data class NetworkInfo(
    val ssid: String,
    val bssid: String,
    val rssi: Int,
    val frequency: Int,
    val channel: Int
)

class WifiAnalyzer(private val context: Context) {

    private val wifiMgr = context.applicationContext
        .getSystemService(Context.WIFI_SERVICE) as WifiManager

    // ── Real WiFi Info ────────────────────────────────
    fun getWifiInfo(): WifiInfo {
        val info = wifiMgr.connectionInfo
        val freq = info.frequency

        val channel = when {
            freq in 2412..2484 -> (freq - 2412) / 5 + 1
            freq in 5170..5825 -> (freq - 5170) / 5 + 34
            else -> 0
        }

        val freqBand = if (freq > 4000) "5 GHz" else "2.4 GHz"
        val rssi     = info.rssi
        val sigLevel = WifiManager.calculateSignalLevel(rssi, 5)
        val sigText  = when (sigLevel) {
            4    -> "ممتاز ████"
            3    -> "جيد ███"
            2    -> "متوسط ██"
            1    -> "ضعيف █"
            else -> "لا إشارة"
        }

        // Convert IP from int to string
        val ipInt = info.ipAddress
        val ip = String.format(
            "%d.%d.%d.%d",
            ipInt and 0xFF,
            (ipInt shr 8) and 0xFF,
            (ipInt shr 16) and 0xFF,
            (ipInt shr 24) and 0xFF
        )

        return WifiInfo(
            ssid        = info.ssid?.replace("\"","") ?: "غير متصل",
            bssid       = info.bssid ?: "—",
            rssi        = rssi,
            frequency   = "$freqBand ($freq MHz)",
            channel     = channel,
            ipAddress   = ip,
            signalLevel = sigText,
            linkSpeed   = info.linkSpeed
        )
    }

    // ── Scan Nearby Networks ──────────────────────────
    suspend fun scanNetworks(): List<NetworkInfo> = withContext(Dispatchers.IO) {
        wifiMgr.startScan()
        android.os.SystemClock.sleep(2000)

        val results: List<ScanResult> = wifiMgr.scanResults ?: return@withContext emptyList()

        results.map { r ->
            val freq = r.frequency
            val ch = when {
                freq in 2412..2484 -> (freq - 2412) / 5 + 1
                freq in 5170..5825 -> (freq - 5170) / 5 + 34
                else -> 0
            }
            NetworkInfo(
                ssid      = r.SSID.ifEmpty { "شبكة مخفية" },
                bssid     = r.BSSID,
                rssi      = r.level,
                frequency = freq,
                channel   = ch
            )
        }.sortedByDescending { it.rssi }
    }

    // ── Find Best Channel ─────────────────────────────
    fun getBestChannel(networks: List<NetworkInfo>): Int {
        val is5GHz = networks.any { it.frequency > 4000 }

        return if (is5GHz) {
            // Count usage per 5GHz channel
            val channels5 = listOf(36, 40, 44, 48, 100, 104, 108, 112, 149, 153, 157, 161)
            val usage = channels5.associateWith { ch ->
                networks.count { it.channel == ch }
            }
            usage.minByOrNull { it.value }?.key ?: 36
        } else {
            // 2.4GHz — only non-overlapping: 1, 6, 11
            val channels24 = listOf(1, 6, 11)
            val usage = channels24.associateWith { ch ->
                networks.count { it.channel == ch }
            }
            usage.minByOrNull { it.value }?.key ?: 6
        }
    }

    // ── Get Router Gateway ────────────────────────────
    fun getGateway(): String {
        val dhcp = wifiMgr.dhcpInfo
        val gw   = dhcp.gateway
        return String.format(
            "%d.%d.%d.%d",
            gw and 0xFF,
            (gw shr 8) and 0xFF,
            (gw shr 16) and 0xFF,
            (gw shr 24) and 0xFF
        )
    }

    // ── Network Score ─────────────────────────────────
    suspend fun calculateNetworkScore(): Int = withContext(Dispatchers.IO) {
        val info  = getWifiInfo()
        var score = 0

        // Signal strength (40 pts)
        score += when {
            info.rssi > -50 -> 40
            info.rssi > -60 -> 32
            info.rssi > -70 -> 22
            else            -> 10
        }

        // Frequency band (20 pts)
        score += if (info.frequency.contains("5 GHz")) 20 else 10

        // Link speed (20 pts)
        score += when {
            info.linkSpeed > 200 -> 20
            info.linkSpeed > 100 -> 15
            info.linkSpeed > 50  -> 10
            else                 -> 5
        }

        // Ping test (20 pts)
        try {
            val start = System.currentTimeMillis()
            InetAddress.getByName("8.8.8.8").isReachable(2000)
            val ping = System.currentTimeMillis() - start
            score += when {
                ping < 30  -> 20
                ping < 60  -> 15
                ping < 100 -> 10
                else       -> 5
            }
        } catch (e: Exception) { score += 0 }

        score.coerceIn(0, 100)
    }
}
